package integracao.componentes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComponentesApplicationTests {

	@Test
	void contextLoads() {
	}

}
